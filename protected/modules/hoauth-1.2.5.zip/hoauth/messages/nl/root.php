<?php
return array (
	'Email' => 'Email',
	'Nickname' => 'Gebruikersnaam',
	'Password' => 'Wachtwoord',
	'Sorry, but password is incorrect' => 'Sorry, uw wachtwoord is onjuist',
	'Submit' => 'Verstuur',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.' => '{attribute} is al door een ander in gebruik. Als dit uw account is, voer dan uw gebruikersnaam is, of verander uw {attribute}.',
	'Please specify your nickname and email to end with registration.' => 'Voer alstublieft uw gebruikersnaam en wachtwoord in, om de registratie te beëindigen.',
	'Please specify your nickname to end with registration.' => 'Voer alstublieft uw gebruikersnaam in, om de registratie te beëindigen.',
	'Please specify your email to end with registration.' => 'Voer alstublieft uw emailadres in, om de registratie te beëindigen.',
	'If you remove this social network account, you will you will not be able to login with it.\\n\\nDo you realy want to remove this account?' => 'Als u dit account verwijderd, kunt u hier niet meer mee inloggen.\\n\\nWeet u zeker dat u dit account wilt verwijderen?',
	'Remove' => 'Verwijderen',

	'Sorry, but your account' => 'Sorry, uw account',
	'must be activated! Check your email for details!' => 'dient  eerst geactiveerd te worden! bekijk uw E-Mail voor de details.',
	'is banned!' => 'is geblokkeerd!',
	'Return to main page' => 'Terug naar de hoofdpagina',
	'Return to login page' => 'Terug naar de inlogpagina',
);
