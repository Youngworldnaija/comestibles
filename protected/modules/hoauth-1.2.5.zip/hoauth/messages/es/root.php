<?php
return array (
	'Email' => 'Email',
	'Nickname' => 'Nickname',
	'Password' => 'Clave',
	'Sorry, but password is incorrect' => 'Lo sentimos, la clave es incorrecta',
	'Submit' => 'Enviar',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.' => 'Este {attribute} ya esta usado por otro usuario. Si esta es tu cuenta, entra una clave en el campo de abajo, o cambia el {attribute} y deje la clave en blanco',
	'Please specify your nickname and email to end with registration.' => 'Por favor especifique su nickname y correo para terminar el proceso de alta.',
	'Please specify your nickname to end with registration.' => 'Por favor especifique su nickname para terminar el proceso de alta.',
	'Please specify your email to end with registration.' => 'Por favor especifique su correo para terminar el proceso de alta.',
	
	'Sorry, but your account' => 'Lo sentimos, su cuenta',
	'must be activated! Check your email for details!' => 'debe ser activada antes de entrar. Por favor compruebe su correo electrónico.',
	'is banned!' => 'ha sido bloqueada.',
	'Return to main page' => 'Volver a la página de inicio',
	'Return to login page' => 'Volver a la página de login',
	'Sign in with' => 'Ingresar con',
);
