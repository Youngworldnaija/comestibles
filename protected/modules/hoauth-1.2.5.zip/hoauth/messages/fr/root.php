<?php
/**
 * @author Thanks to FredT69 (http://www.yiiframework.com/user/97734/)
 */
return array (
    'Email' => 'Email',
	'Nickname' => 'Pseudo',
	'Password' => 'Mot de passe',
	'Sorry, but password is incorrect' => 'Désolé, mais le mot de passe est incorrect',
	'Submit' => 'Envoyer',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.'        => 'Ce {attribute} est pris par un autre utilisateur. S\'il s\'agit de votre compte, entrez le mot de passe dans le champ ci-dessous ou changer le {attribute} et laisser le mot de passe vierge.',
	'Please specify your nickname and email to end with registration.' => 'S\'il vous plaît préciser votre pseudo et email pour terminer l\'inscription.',
	'Please specify your nickname to end with registration.' => 'S\'il vous plaît préciser votre pseudo pour terminer l\'inscription.',
	'Please specify your email to end with registration.' => 'S\'il vous plaît préciser votre email pour terminer l\'inscription.',
	'If you remove this social network account, you will you will not be able to login with it.\\n\\nDo you realy want to remove this account?' => 'Si vous supprimez ce compte de réseau social, vous ne pourrez plus vous connecter avec lui . \\n\\n Voulez-vous vraiment le supprimer?',
	'Remove' => 'Supprimer',

	'Sorry, but your account' => 'Désolé, mais votre compte',
	'must be activated! Check your email for details!' => 'doit être activée! Vérifiez votre email pour plus de détails!',
	'is banned!' => 'est banni',
	'Return to main page' => 'Retour à l\'accueil',
	'Return to login page' => 'Retour à la page de connexion',
    
    'Sign in with' => 'Connectez-vous avec',
    'Connect with' => 'Connecté avec ',
);
