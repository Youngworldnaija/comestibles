<?php
return array (
	'Email' => 'Email',
	'Nickname' => 'Nome utente',
	'Password' => 'Password',
	'Sorry, but password is incorrect' => 'Spiacente, ma la password non è corretta',
	'Submit' => 'Enviar',
	'This {attribute} is taken by another user. If this is your account, enter password in field below or change {attribute} and leave password blank.' => 'Quest {attribute} è già utilizzato da un altro utente. Se questo è il tuo account inserisci la password nel campo sottostante altrimenti cambia {attribute} e lascia il campo password vuoto',
	'Please specify your nickname and email to end with registration.' => 'Per favore specifica il tuo nome utente e l\'email per portare a termine la registrazione.',
	'Please specify your nickname to end with registration.' => 'Per favore specifica il tuo nome utente per portare a termine la registrazione.',
	'Please specify your email to end with registration.' => 'Per favore specifica l\'email per portare a termine la registrazione.',
	
	'Sorry, but your account' => 'Siamo spiacenti, ma il suo account',
	'must be activated! Check your email for details!' => 'deve essere attivato prima di accedere! Per favore controlli la sua casella di posta elettronica per dettagli.',
	'is banned!' => 'è stato bloccato.',
	'Return to main page' => 'Ritorna alla pagiana principale',
	'Return to login page' => 'Ritorna alla pagiana di login',
);
